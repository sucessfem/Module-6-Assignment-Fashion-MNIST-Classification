# Module 6 Assignment

## Project Overview
This project implements a Convolutional Neural Network (CNN) to classify images from the Fashion MNIST dataset. 

## Overview

The script performs the following tasks:
1. Loads and preprocesses the Fashion MNIST dataset
2. Defines and compiles a CNN model
3. Trains the model on the dataset
4. Evaluates the model's performance
5. Makes predictions on sample images and visualizes the results

## Requirements
- Python 3.7+
- TensorFlow 2.x
- NumPy
- Matplotlib

## Installation
1. Ensure you have Python 3.7 or later installed.

### Code Explanation
```python
from tensorflow.keras import layers, models
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
```
- This section imports the necessary libraries: TensorFlow for the neural network, NumPy for numerical operations, and Matplotlib for plotting.

```python
# Step 1: Load the training and test data
(training_images, training_labels), (testing_images, testing_labels) = tf.keras.fashion_mnist.load_data()

# Step 2: Normalize and reshape images
training_images = training_images.reshape(-1, 28, 28, 1).astype('float32') / 255
testing_images = testing_images.reshape(-1, 28, 28, 1).astype('float32') / 255
```
- This code loads the Fashion MNIST dataset, normalizes the pixel values to be between 0 and 1, and reshapes the images to include a channel dimension.

```python
model = models.Sequential([
    layers.Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(64, (3, 3), activation='relu'),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(64, (3, 3), activation='relu'),
    layers.Flatten(),
    layers.Dense(64, activation='relu'),
    layers.Dense(10, activation='softmax')
])
```
- This creates a sequential model with three convolutional layers, two max pooling layers, and two dense layers. The final layer has 10 neurons, one for each class in the dataset.

```python
model.compile(
    optimizer='adam',
    loss=tf.keras.losses.SparseCategoricalCrossentropy(),
    metrics=['accuracy']
)

model.summary()
```
- This code compiles the model and also displays the model summary.

```python
training_history = model.fit(
    training_images, training_labels, 
    epochs=10, 
    validation_split=0.2
)

test_loss, test_accuracy = model.evaluate(testing_images, testing_labels, verbose=2)
print(f'\nTest Accuracy: {test_accuracy:.5f}')
```
- This code trains the model on the training data for 10 epochs, using 20% of the training data for validation. The code also displays the test accuracy.

```python
sample_images = testing_images[:2]

predictions = model.predict(sample_images)
predicted_classes = np.argmax(predictions, axis=1)
```
- This uses the trained model to make predictions on two sample images.

```python
# Step 8: Display the predictions
for index, prediction_class_names in enumerate(predicted_classes):
    print(f"Prediction for sample {index + 1}: {class_names[prediction_class_names]}")
    
# Step 9: Display the images
plt.figure(figsize=(10,5))
plt.subplot(121)
plt.imshow(sample_images[0].reshape(28,28), cmap='gray')
plt.title(f"Predicted: {class_names[predicted_classes[0]]}")
plt.subplot(122)
plt.imshow(sample_images[1].reshape(28,28), cmap='gray')
plt.title(f"Predicted: {class_names[predicted_classes[1]]}")
plt.show()
```
- This code displays the predictions and also displays the images.