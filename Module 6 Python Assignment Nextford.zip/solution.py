from tensorflow.keras import layers, models
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt

# Step 1: Load the training and test data
(training_images, training_labels), (testing_images, testing_labels) = tf.keras.fashion_mnist.load_data()

# Step 2: Normalize and reshape images
training_images = training_images.reshape(-1, 28, 28, 1).astype('float32') / 255
testing_images = testing_images.reshape(-1, 28, 28, 1).astype('float32') / 255

# Step 3: Define the Convolutional Neural Network model
model = models.Sequential([
    layers.Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(64, (3, 3), activation='relu'),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(64, (3, 3), activation='relu'),
    layers.Flatten(),
    layers.Dense(64, activation='relu'),
    layers.Dense(10, activation='softmax')
])

# Step 4: Compile the model and display the model summary
model.compile(
    optimizer='adam',
    loss=tf.keras.losses.SparseCategoricalCrossentropy(),
    metrics=['accuracy']
)

model.summary()

# Step 5: Train and Evaluate the model, and Display the Test Accuracy
training_history = model.fit(
    training_images, training_labels, 
    epochs=10, 
    validation_split=0.2
)

test_loss, test_accuracy = model.evaluate(testing_images, testing_labels, verbose=2)
print(f'\nTest Accuracy: {test_accuracy:.5f}')

# Step 6: Choose images from the test set and make predictions
sample_images = testing_images[:2]

predictions = model.predict(sample_images)
predicted_classes = np.argmax(predictions, axis=1)

# Step 7: Define class names
class_names = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat', 
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

# Step 8: Display the predictions
for index, prediction_class_names in enumerate(predicted_classes):
    print(f"Prediction for sample {index + 1}: {class_names[prediction_class_names]}")
    
# Step 9: Display the images
plt.figure(figsize=(10,5))
plt.subplot(121)
plt.imshow(sample_images[0].reshape(28,28), cmap='gray')
plt.title(f"Predicted: {class_names[predicted_classes[0]]}")
plt.subplot(122)
plt.imshow(sample_images[1].reshape(28,28), cmap='gray')
plt.title(f"Predicted: {class_names[predicted_classes[1]]}")
plt.show()